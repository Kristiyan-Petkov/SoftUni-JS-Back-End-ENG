module.exports = {
    PORT: 3000,
    DB_CONNECTION_STRING: 'mongodb://localhost:27017/exam-db',
    TOKEN_SECRET: 'foryoumyfriednspecialprice101',
    COOKIE_NAME: 'SESSION_TOKEN'
}